package pe.edu.cibertec.api_practica_t2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiPracticaT2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiPracticaT2Application.class, args);
	}

}
