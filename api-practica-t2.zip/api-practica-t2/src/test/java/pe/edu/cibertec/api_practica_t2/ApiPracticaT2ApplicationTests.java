package pe.edu.cibertec.api_practica_t2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiPracticaT2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
